import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../account/presentation/account_provider.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Determine if the screen is a tablet based on width
    final isTablet = MediaQuery.of(context).size.width > 600;
    final accountProvider = Provider.of<AccountProvider>(context);

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: Text(
          "Welcome back, ${accountProvider.userFirstName}!", // Dynamic Name
          style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 18),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: accountProvider.isLoading
          ? const Center(child: CircularProgressIndicator())
          : Padding(
              padding: const EdgeInsets.all(16.0),
              // THIS IS THE FIX: Actively routing the layout based on the device screen size
              child: isTablet
                  ? _buildTabletLayout(accountProvider)
                  : _buildPhoneLayout(accountProvider),
            ),
    );
  }

  // Layout for standard smartphones
  Widget _buildPhoneLayout(AccountProvider provider) {
    return SingleChildScrollView(
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          _buildLiveBalanceCard(provider), // Using dynamic SQLite data
          const SizedBox(height: 24),
          _buildQuickActions(),
          const SizedBox(height: 24),
          const Text(
            'Recent Transactions',
            style: TextStyle(
              fontSize: 18,
              fontWeight: FontWeight.bold,
              color: Color(0xFF0A2540),
            ),
          ),
          const SizedBox(height: 12),
          _buildTransactionList(),
        ],
      ),
    );
  }

  // Layout for Tablets (Side-by-side split screen view)
  Widget _buildTabletLayout(AccountProvider provider) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        // Left Column: Account Balances & Quick Actions
        Expanded(
          flex: 4,
          child: SingleChildScrollView(
            child: Column(
              children: [
                _buildLiveBalanceCard(provider), // Using dynamic SQLite data
                const SizedBox(height: 24),
                _buildQuickActions(),
              ],
            ),
          ),
        ),
        const SizedBox(width: 24),
        // Right Column: Transactions List
        Expanded(
          flex: 5,
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Recent Transactions',
                style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0A2540),
                ),
              ),
              const SizedBox(height: 12),
              Expanded(child: _buildTransactionList()),
            ],
          ),
        ),
      ],
    );
  }

  // Refactored Reusable Live Balance Card
  Widget _buildLiveBalanceCard(AccountProvider provider) {
    return Container(
      padding: const EdgeInsets.all(24),
      decoration: BoxDecoration(
        color: const Color(0xFF0A2540),
        borderRadius: BorderRadius.circular(20),
        boxShadow: [
          BoxShadow(
            color: Colors.blueGrey.withOpacity(0.3),
            blurRadius: 10,
            offset: const Offset(0, 5),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Total Available Balance",
            style: TextStyle(color: Colors.white70, fontSize: 14),
          ),
          const SizedBox(height: 8),
          Text(
            "\$${provider.currentBalance.toStringAsFixed(2)}", // Real SQLite Balance
            style: const TextStyle(
              color: Colors.white,
              fontSize: 36,
              fontWeight: FontWeight.bold,
            ),
          ),
        ],
      ),
    );
  }

  // Reusable Quick Actions Hub
  Widget _buildQuickActions() {
    return Row(
      mainAxisAlignment: MainAxisAlignment.spaceAround,
      children: [
        _actionButton(Icons.swap_horiz, 'Transfer'),
        _actionButton(Icons.credit_card, 'Cards'),
        _actionButton(Icons.receipt_long, 'Bill Pay'),
        _actionButton(Icons.trending_up, 'Analytics'),
      ],
    );
  }

  Widget _actionButton(IconData icon, String label) {
    return Column(
      children: [
        CircleAvatar(
          radius: 28,
          backgroundColor: Colors.blueGrey[50],
          child: Icon(icon, color: const Color(0xFF0A2540)),
        ),
        const SizedBox(height: 8),
        Text(
          label,
          style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w500),
        ),
      ],
    );
  }

  // Reusable Mock Transaction List Component
  // (We'll leave this mock list here for UI purposes, but you can wire it to TransferProvider later if needed!)
  Widget _buildTransactionList() {
    final transactions = [
      {
        'title': 'Netflix Subscription',
        'date': 'June 1',
        'amount': '-\$14.99',
        'type': 'expense',
      },
      {
        'title': 'Starbucks Coffee',
        'date': 'May 28',
        'amount': '-\$6.75',
        'type': 'expense',
      },
      {
        'title': 'Payroll Direct Deposit',
        'date': 'May 25',
        'amount': '+\$2,500.00',
        'type': 'income',
      },
    ];

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: transactions.length,
      itemBuilder: (context, index) {
        final tx = transactions[index];
        final isIncome = tx['type'] == 'income';
        return Card(
          margin: const EdgeInsets.symmetric(vertical: 6),
          child: ListTile(
            leading: CircleAvatar(
              backgroundColor: isIncome ? Colors.green[50] : Colors.red[50],
              child: Icon(
                isIncome ? Icons.arrow_downward : Icons.arrow_upward,
                color: isIncome ? Colors.green : Colors.red,
              ),
            ),
            title: Text(
              tx['title']!,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(tx['date']!),
            trailing: Text(
              tx['amount']!,
              style: TextStyle(
                fontWeight: FontWeight.bold,
                color: isIncome ? Colors.green : Colors.black,
              ),
            ),
          ),
        );
      },
    );
  }
}
