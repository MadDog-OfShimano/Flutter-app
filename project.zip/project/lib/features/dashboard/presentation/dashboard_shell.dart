import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class DashboardShell extends StatelessWidget {
  final Widget child;

  const DashboardShell({super.key, required this.child});

  // Maps the current route string back to our BottomNavigationBar items
  int _calculateSelectedIndex(BuildContext context) {
    final String location = GoRouterState.of(context).matchedLocation;
    if (location.startsWith('/account')) return 0;
    if (location.startsWith('/transfers')) return 1;
    if (location.startsWith('/transactions')) return 2;
    if (location.startsWith('/cards')) return 3;
    if (location.startsWith('/notifications')) return 4;
    if (location.startsWith('/settings')) return 5;
    if (location.startsWith('/help')) return 6;
    return 0;
  }

  // Handles switching tabs using go_router paths
  void _onItemTapped(int index, BuildContext context) {
    switch (index) {
      case 0:
        context.go('/account');
        break;
      case 1:
        context.go('/transfers');
        break;
      case 2:
        context.go('/transactions');
        break;
      case 3:
        context.go('/cards');
        break;
      case 4:
        context.go('/notifications');
        break;
      case 5:
        context.go('/settings');
        break;
      case 6:
        context.go('/help');
        break;
    }
  }

  @override
  Widget build(BuildContext context) {
    final int selectedIndex = _calculateSelectedIndex(context);

    return Scaffold(
      body: child, // sub-page widgets will be rendered here
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          boxShadow: [
            BoxShadow(
              color: Colors.black.withOpacity(0.05),
              blurRadius: 10,
              spreadRadius: 2,
            ),
          ],
        ),
        child: BottomNavigationBar(
          currentIndex: selectedIndex,
          onTap: (index) => _onItemTapped(index, context),
          type:
              BottomNavigationBarType.shifting, // Gives a clean shift animation
          selectedItemColor: const Color(0xFF0A2540),
          unselectedItemColor: Colors.grey[400],
          showUnselectedLabels: false,
          selectedLabelStyle: const TextStyle(
            fontWeight: FontWeight.bold,
            fontSize: 12,
          ),
          items: const [
            BottomNavigationBarItem(
              icon: Icon(Icons.person_outline),
              activeIcon: Icon(Icons.person),
              label: 'Account',
              backgroundColor: Colors.white,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.swap_horizontal_circle_outlined),
              activeIcon: Icon(Icons.swap_horizontal_circle),
              label: 'Transfers',
              backgroundColor: Colors.white,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.receipt_long_outlined),
              activeIcon: Icon(Icons.receipt_long),
              label: 'History',
              backgroundColor: Colors.white,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.credit_card_outlined),
              activeIcon: Icon(Icons.credit_card),
              label: 'Cards',
              backgroundColor: Colors.white,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.notifications_outlined),
              activeIcon: Icon(Icons.notifications),
              label: 'Alerts',
              backgroundColor: Colors.white,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.settings_outlined),
              activeIcon: Icon(Icons.settings),
              label: 'Settings',
              backgroundColor: Colors.white,
            ),
            BottomNavigationBarItem(
              icon: Icon(Icons.help_outline_rounded),
              activeIcon: Icon(Icons.help_rounded),
              label: 'Help',
              backgroundColor: Colors.white,
            ),
          ],
        ),
      ),
    );
  }
}
