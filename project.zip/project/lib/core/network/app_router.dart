import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

// Shell and Auth Screens
import '../../features/dashboard/presentation/dashboard_shell.dart';
import '../../features/dashboard/presentation/dashboard_screen.dart';
import '../../features/auth/presentation/login_screen.dart';
import '../../features/auth/presentation/mfa_screen.dart';
import '../../features/auth/presentation/signup_screen.dart';
import '../../features/auth/presentation/auth_provider.dart';
import '../../features/admin/presentation/admin_dashboard_screen.dart';

// Placeholder views for our 7 foundational screens
import '../../features/account/presentation/account_screen.dart';
import '../../features/transfers/presentation/transfers_screen.dart';
import '../../features/transactions/presentation/transactions_screen.dart';
import '../../features/cards/presentation/cards_screen.dart';
import '../../features/notifications/presentation/notifications_screen.dart';
import '../../features/settings/presentation/settings_screen.dart';
import '../../features/help/presentation/help_screen.dart';

final GlobalKey<NavigatorState> _rootNavigatorKey = GlobalKey<NavigatorState>(
  debugLabel: 'root',
);
final GlobalKey<NavigatorState> _shellNavigatorKey = GlobalKey<NavigatorState>(
  debugLabel: 'shell',
);

final GoRouter appRouter = GoRouter(
  navigatorKey: _rootNavigatorKey,
  initialLocation: '/login',
  redirect: (BuildContext context, GoRouterState state) {
    final authProvider = Provider.of<AuthProvider>(context, listen: false);
    final isLoggingIn = state.matchedLocation == '/login';
    final isVerifyingMfa = state.matchedLocation == '/mfa';
    final isSigningUp = state.matchedLocation == '/signup';
    final isAdmin =
        state.matchedLocation == '/admin'; // NEW: Check for admin route

    if (!authProvider.isAuthenticated) {
      // Allow access to login, mfa, signup AND the admin portal if not authenticated
      if (isLoggingIn || isVerifyingMfa || isSigningUp || isAdmin) return null;
      return '/login';
    }

    // If logged in, protect auth flows by sending them inside the dashboard shell
    if (authProvider.isAuthenticated &&
        (isLoggingIn || isVerifyingMfa || isSigningUp)) {
      return '/dashboard'; // CHANGED: Routes to Dashboard instead of Account on successful login
    }

    return null;
  },
  routes: [
    // Auth & Admin Screens (Outside the bottom bar framework navigation shell)
    GoRoute(
      path: '/login',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const LoginScreen(),
    ),
    GoRoute(
      path: '/signup',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const SignupScreen(),
    ),
    GoRoute(
      path: '/mfa',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const MfaScreen(),
    ),
    // NEW: The Admin Route
    GoRoute(
      path: '/admin',
      parentNavigatorKey: _rootNavigatorKey,
      builder: (context, state) => const AdminDashboardScreen(),
    ),

    // Dashboard Navigation Core Shell Envelope
    ShellRoute(
      navigatorKey: _shellNavigatorKey,
      builder: (context, state, child) {
        return DashboardShell(child: child);
      },
      routes: [
        // NEW: The Main Live Balance Dashboard
        GoRoute(
          path: '/dashboard',
          parentNavigatorKey: _shellNavigatorKey,
          pageBuilder: (context, state) =>
              const NoTransitionPage(child: DashboardScreen()),
        ),
        GoRoute(
          path: '/account',
          parentNavigatorKey: _shellNavigatorKey,
          pageBuilder: (context, state) =>
              const NoTransitionPage(child: AccountScreen()),
        ),
        GoRoute(
          path: '/transfers',
          parentNavigatorKey: _shellNavigatorKey,
          pageBuilder: (context, state) =>
              const NoTransitionPage(child: TransfersScreen()),
        ),
        GoRoute(
          path: '/transactions',
          parentNavigatorKey: _shellNavigatorKey,
          pageBuilder: (context, state) =>
              const NoTransitionPage(child: TransactionsScreen()),
        ),
        GoRoute(
          path: '/cards',
          parentNavigatorKey: _shellNavigatorKey,
          pageBuilder: (context, state) =>
              const NoTransitionPage(child: CardsScreen()),
        ),
        GoRoute(
          path: '/notifications',
          parentNavigatorKey: _shellNavigatorKey,
          pageBuilder: (context, state) =>
              const NoTransitionPage(child: NotificationsScreen()),
        ),
        GoRoute(
          path: '/settings',
          parentNavigatorKey: _shellNavigatorKey,
          pageBuilder: (context, state) =>
              const NoTransitionPage(child: SettingsScreen()),
        ),
        GoRoute(
          path: '/help',
          parentNavigatorKey: _shellNavigatorKey,
          pageBuilder: (context, state) =>
              const NoTransitionPage(child: HelpScreen()),
        ),
      ],
    ),
  ],
);
