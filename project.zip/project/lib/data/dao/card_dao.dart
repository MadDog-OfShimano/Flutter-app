import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/card_model.dart';

class CardDao {
  final _dbProvider = AppDatabase.instance;

  // INSERTS a new card. Will throw an exception if card_number_hash already exists.
  Future<int> insertCard(CardModel card) async {
    final db = await _dbProvider.database;
    return await db.insert(
      'cards',
      card.toMap(),
      // We do NOT use ConflictAlgorithm.replace here.
      // We want it to fail so we can catch the duplicate attempt and inform the user to use a different card.
      conflictAlgorithm: ConflictAlgorithm.abort,
    );
  }

  // READS all cards belonging to the logged-in user
  Future<List<CardModel>> getCardsByUserId(String userId) async {
    final db = await _dbProvider.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'cards',
      where: 'user_id = ?',
      whereArgs: [userId],
    );

    return maps.map((map) => CardModel.fromMap(map)).toList();
  }

  // UPDATES the online purchasing toggle
  Future<int> updateOnlineStatus(String cardId, bool isEnabled) async {
    final db = await _dbProvider.database;
    return await db.update(
      'cards',
      {'is_online_enabled': isEnabled ? 1 : 0},
      where: 'id = ?',
      whereArgs: [cardId],
    );
  }

  // DELETES a specific card
  Future<int> deleteCard(String cardId) async {
    final db = await _dbProvider.database;
    return await db.delete('cards', where: 'id = ?', whereArgs: [cardId]);
  }
}
