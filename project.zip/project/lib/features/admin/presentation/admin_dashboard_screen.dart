import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'dart:io';
import 'admin_provider.dart';
import '../../../data/models/user_model.dart';

class AdminDashboardScreen extends StatelessWidget {
  const AdminDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final adminProvider = Provider.of<AdminProvider>(context);

    // Show login screen if not authenticated
    if (!adminProvider.isAdminAuthenticated) {
      return const _AdminLoginView();
    }

    // Show the dual-tab dashboard if authenticated
    return DefaultTabController(
      length: 2,
      child: Scaffold(
        appBar: AppBar(
          title: const Text(
            "System Administration",
            style: TextStyle(fontWeight: FontWeight.bold),
          ),
          backgroundColor: const Color(0xFF0A2540),
          foregroundColor: Colors.white,
          actions: [
            IconButton(
              icon: const Icon(Icons.logout),
              onPressed: adminProvider.logoutAdmin,
            ),
          ],
          bottom: const TabBar(
            labelColor: Colors.white,
            unselectedLabelColor: Colors.white54,
            indicatorColor: Colors.blue,
            tabs: [
              Tab(icon: Icon(Icons.pending_actions), text: "Pending Requests"),
              Tab(icon: Icon(Icons.people), text: "Current Users"),
            ],
          ),
        ),
        body: const TabBarView(
          children: [_PendingRequestsTab(), _CurrentUsersTab()],
        ),
      ),
    );
  }
}

// --- LOGIN SUB-VIEW ---
class _AdminLoginView extends StatefulWidget {
  const _AdminLoginView();
  @override
  State<_AdminLoginView> createState() => _AdminLoginViewState();
}

class _AdminLoginViewState extends State<_AdminLoginView> {
  final _usernameController = TextEditingController();
  final _passwordController = TextEditingController();

  void _handleLogin() async {
    final success = await Provider.of<AdminProvider>(
      context,
      listen: false,
    ).loginAdmin(_usernameController.text, _passwordController.text);

    if (!success && mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text("Invalid admin credentials"),
          backgroundColor: Colors.red,
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Admin Portal")),
      body: Padding(
        padding: const EdgeInsets.all(32.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(
              Icons.admin_panel_settings,
              size: 80,
              color: Color(0xFF0A2540),
            ),
            const SizedBox(height: 32),
            TextField(
              controller: _usernameController,
              decoration: const InputDecoration(
                labelText: "Admin Username",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: const InputDecoration(
                labelText: "Master Password",
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 24),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: const Color(0xFF0A2540),
                foregroundColor: Colors.white,
                minimumSize: const Size(double.infinity, 50),
              ),
              onPressed: _handleLogin,
              child: const Text("Secure Login"),
            ),
          ],
        ),
      ),
    );
  }
}

// --- PENDING REQUESTS TAB ---
class _PendingRequestsTab extends StatelessWidget {
  const _PendingRequestsTab();

  void _showPendingDetails(BuildContext context, UserModel user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Applicant Details"),
        content: Column(
          mainAxisSize: MainAxisSize.min, // Prevents vertical overflow
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Name: ${user.fullName}", style: const TextStyle(fontWeight: FontWeight.bold)),
            Text("Email: ${user.email}"),
            Text("Phone: ${user.phoneNumber}"),
            const SizedBox(height: 16),
            const Text("Uploaded ID Document:", style: TextStyle(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),

            // THE FIX: Bounded container with a fallback error builder
            Container(
              height: 150,
              width: double.infinity,
              decoration: BoxDecoration(
                color: Colors.grey[200],
                borderRadius: BorderRadius.circular(8),
                border: Border.all(color: Colors.grey[300]!),
              ),
              child: user.idDocumentPath.isEmpty
                  ? const Center(child: Text("No ID Provided", style: TextStyle(color: Colors.grey)))
                  : ClipRRect(
                borderRadius: BorderRadius.circular(8),
                child: Image.file(
                  File(user.idDocumentPath),
                  fit: BoxFit.cover,
                  // If the file path is fake or the file is missing, show a broken image icon instead of crashing
                  errorBuilder: (context, error, stackTrace) {
                    return const Center(
                      child: Icon(Icons.broken_image, color: Colors.grey, size: 40),
                    );
                  },
                ),
              ),
            ),
          ],
        ),
        actions: [
          TextButton(
            style: TextButton.styleFrom(foregroundColor: Colors.red),
            onPressed: () {
              Provider.of<AdminProvider>(context, listen: false).rejectUser(user.id, user.phoneNumber);
              Navigator.pop(context);
            },
            child: const Text("Reject & Ban"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: Colors.green, foregroundColor: Colors.white),
            onPressed: () {
              Provider.of<AdminProvider>(context, listen: false).approveUser(user.id);
              Navigator.pop(context);
            },
            child: const Text("Approve Account"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final pending = Provider.of<AdminProvider>(context).pendingUsers;
    if (pending.isEmpty) return const Center(child: Text("Queue is empty."));

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: pending.length,
      itemBuilder: (context, index) {
        final user = pending[index];
        return Card(
          child: ListTile(
            leading: const Icon(Icons.person_add, color: Colors.orange),
            title: Text(
              user.fullName,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(user.phoneNumber),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () => _showPendingDetails(context, user),
          ),
        );
      },
    );
  }
}

// --- CURRENT USERS TAB ---
class _CurrentUsersTab extends StatelessWidget {
  const _CurrentUsersTab();

  void _showActiveUserDetails(BuildContext context, UserModel user) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Account Management"),
        content: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              "Name: ${user.fullName}",
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            Text("IBAN: ${user.iban}"),
            Text("Balance: \$${user.balance.toStringAsFixed(2)}"),
            const SizedBox(height: 16),
            const Text(
              "Warning: Deleting this account will permanently erase all associated cards and transaction history.",
              style: TextStyle(color: Colors.red, fontSize: 12),
            ),
          ],
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: Colors.red,
              foregroundColor: Colors.white,
            ),
            onPressed: () {
              // The "Are you sure?" confirmation
              showDialog(
                context: context,
                builder: (context) => AlertDialog(
                  title: const Text("Are you absolutely sure?"),
                  actions: [
                    TextButton(
                      onPressed: () => Navigator.pop(context),
                      child: const Text("No"),
                    ),
                    ElevatedButton(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.red,
                        foregroundColor: Colors.white,
                      ),
                      onPressed: () {
                        Provider.of<AdminProvider>(
                          context,
                          listen: false,
                        ).deleteActiveAccount(user.id);
                        Navigator.pop(context); // Close confirmation
                        Navigator.pop(context); // Close details
                      },
                      child: const Text("Yes, Delete"),
                    ),
                  ],
                ),
              );
            },
            child: const Text("Delete Account"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final active = Provider.of<AdminProvider>(context).activeUsers;
    if (active.isEmpty) return const Center(child: Text("No active users."));

    return ListView.builder(
      padding: const EdgeInsets.all(16),
      itemCount: active.length,
      itemBuilder: (context, index) {
        final user = active[index];
        return Card(
          child: ListTile(
            leading: const Icon(Icons.verified_user, color: Colors.green),
            title: Text(
              user.fullName,
              style: const TextStyle(fontWeight: FontWeight.bold),
            ),
            subtitle: Text(user.iban),
            trailing: const Icon(Icons.arrow_forward_ios, size: 16),
            onTap: () => _showActiveUserDetails(context, user),
          ),
        );
      },
    );
  }
}
