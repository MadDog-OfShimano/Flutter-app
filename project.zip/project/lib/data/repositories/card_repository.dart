import '../dao/card_dao.dart';
import '../models/card_model.dart';
import 'package:uuid/uuid.dart';
import 'package:crypto/crypto.dart';
import 'dart:convert';
import 'package:sqflite/sqflite.dart';

class CardRepository {
  final CardDao _cardDao = CardDao();
  final _uuid = const Uuid();

  // Helper function to create a secure, one-way hash of the 16-digit card number
  String _hashCardNumber(String cardNumber) {
    final cleanNumber = cardNumber.replaceAll(
      RegExp(r'\D'),
      '',
    ); // Strip spaces
    final bytes = utf8.encode(cleanNumber);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  // Helper function to create the '**** **** **** 1234' format
  String _maskCardNumber(String cardNumber) {
    final cleanNumber = cardNumber.replaceAll(RegExp(r'\D'), '');
    if (cleanNumber.length < 4) return cleanNumber;
    final lastFour = cleanNumber.substring(cleanNumber.length - 4);
    return '**** **** **** $lastFour';
  }

  /// Attempts to link a new card to a user.
  /// Returns 'SUCCESS', 'DUPLICATE', or 'ERROR'.
  Future<String> addCard({
    required String userId,
    required String rawCardNumber,
    required String expiryDate,
    required String cardType,
  }) async {
    try {
      final newCard = CardModel(
        id: _uuid.v4(),
        userId: userId,
        cardNumberHash: _hashCardNumber(rawCardNumber),
        maskedNumber: _maskCardNumber(rawCardNumber),
        expiryDate: expiryDate,
        cardType: cardType,
      );

      await _cardDao.insertCard(newCard);
      return 'SUCCESS';
    } on DatabaseException catch (e) {
      // SQLite error code 1555 or 2067 generally indicates a UNIQUE constraint failure
      if (e.isUniqueConstraintError()) {
        return 'DUPLICATE';
      }
      return 'ERROR';
    } catch (e) {
      return 'ERROR';
    }
  }

  Future<List<CardModel>> fetchUserCards(String userId) async {
    return await _cardDao.getCardsByUserId(userId);
  }

  Future<void> toggleOnlineStatus(String cardId, bool currentStatus) async {
    await _cardDao.updateOnlineStatus(cardId, !currentStatus);
  }

  Future<void> removeCard(String cardId) async {
    await _cardDao.deleteCard(cardId);
  }
}
