class IbanValidator {
  /// Validates a Turkish IBAN string using the ISO 13616 MOD97 standard rules.
  static String? validateTurkishIban(String? value) {
    if (value == null || value.isEmpty) {
      return 'Please enter an IBAN number.';
    }

    // Clean up spaces and convert to uppercase
    String cleaned = value.replaceAll(' ', '').toUpperCase();

    // Rule 1: Must be exactly 26 characters long
    if (cleaned.length != 26) {
      return 'A Turkish IBAN must be exactly 26 characters (Current: ${cleaned.length}).';
    }

    // Rule 2: Must start with TR
    if (!cleaned.startsWith('TR')) {
      return 'IBAN must begin with the country code "TR".';
    }

    // Rule 3: The characters after TR must be numbers
    String trailingDigits = cleaned.substring(2);
    if (!RegExp(r'^\d+$').hasMatch(trailingDigits)) {
      return 'IBAN must contain only digits after "TR".';
    }

    // Rule 4: MOD97 Math Verification Check
    // Move "TR" and the check digits (first 4 characters) to the end
    String frontFour = cleaned.substring(0, 4); // e.g. "TR22"
    String remainderDigits = cleaned.substring(
      4,
    ); // The rest of the bank/account number

    // Convert letters to numbers: T = 30, R = 27
    String rearranged = remainderDigits + "3027" + frontFour.substring(2);

    // Run Modulo 97 on the giant string integer using BigInt to prevent overflow errors
    BigInt numericRepresentation = BigInt.parse(rearranged);
    BigInt checksumResult = numericRepresentation % BigInt.from(97);

    // If the remainder is exactly 1, the checksum passes perfectly.
    if (checksumResult.toInt() != 1) {
      return 'Invalid IBAN checksum. Please verify the numbers.';
    }

    return null; // Passes all checks.
  }
}

//me when math (*_*)
