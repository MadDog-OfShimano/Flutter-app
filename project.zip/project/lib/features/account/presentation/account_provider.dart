import 'package:flutter/material.dart';
import '../../../data/dao/user_dao.dart';
import '../../../data/models/user_model.dart';

class AccountProvider extends ChangeNotifier {
  final UserDao _userDao = UserDao();
  UserModel? _currentUser;
  bool _isLoading = true;

  UserModel? get currentUser => _currentUser;
  bool get isLoading => _isLoading;

  // Safe UI getters that won't crash if the user hasn't loaded yet
  double get currentBalance => _currentUser?.balance ?? 0.0;
  String get userFirstName => _currentUser?.fullName.split(' ').first ?? 'User';

  // Loads the data upon login
  Future<void> loadUserData(String userId) async {
    _isLoading = true;
    notifyListeners();

    _currentUser = await _userDao.getUserById(userId);

    _isLoading = false;
    notifyListeners();
  }

  // Called to silently update the dashboard after sending money
  Future<void> refreshBalance() async {
    if (_currentUser != null) {
      _currentUser = await _userDao.getUserById(_currentUser!.id);
      notifyListeners();
    }
  }
}
