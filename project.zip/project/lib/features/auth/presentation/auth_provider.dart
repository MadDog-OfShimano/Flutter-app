import 'package:flutter/material.dart';
import '../../../data/repositories/user_repository.dart';
import '../../../data/models/user_model.dart';

class AuthProvider extends ChangeNotifier {
  final UserRepository _userRepo = UserRepository();
  UserModel? _currentUser;

  UserModel? get currentUser => _currentUser;
  bool get isAuthenticated => _currentUser != null;

  // Checks the database for the user and verifies the hashed password
  Future<bool> login(String email, String password) async {
    final user = await _userRepo.authenticateUser(email, password);

    if (user != null) {
      _currentUser = user;
      notifyListeners();
      return true; // Password matched, user exists
    }
    return false; // Invalid credentials
  }

  void logout() {
    _currentUser = null;
    notifyListeners();
  }
}
