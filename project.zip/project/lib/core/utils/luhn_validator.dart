class LuhnValidator {
  /// Runs the Luhn Algorithm (Modulus 10) to validate credit/debit card numbers.
  static String? validateCardNumber(String? value) {
    if (value == null || value.isEmpty) return 'Please enter a card number.';

    // Remove any spaces or dashes the user might have typed
    String cleaned = value.replaceAll(RegExp(r'\D'), '');

    if (cleaned.length < 13 || cleaned.length > 19) {
      return 'Invalid card length. Must be 13-19 digits.';
    }

    int sum = 0;
    bool isAlternate = false;

    // Loop through the digits from right to left
    for (int i = cleaned.length - 1; i >= 0; i--) {
      int digit = int.parse(cleaned[i]);

      if (isAlternate) {
        digit *= 2;
        if (digit > 9) {
          digit -= 9; // Equivalent to adding the two digits of the product
        }
      }

      sum += digit;
      isAlternate = !isAlternate;
    }

    if (sum % 10 != 0) {
      return 'Invalid card number checksum (Failed Luhn check).';
    }

    return null; // Passes validation!
  }

  /// Validates that an MM/YY string is in the future
  static String? validateExpiryDate(String? value) {
    if (value == null || value.isEmpty) return 'Required';

    final regex = RegExp(r'^(0[1-9]|1[0-2])\/?([0-9]{2})$');
    if (!regex.hasMatch(value)) return 'Use MM/YY format';

    // Extract month and year
    final parts = value.split('/');
    final month = int.parse(parts[0]);
    final year = int.parse("20${parts[1]}"); // Assuming 2000s

    final now = DateTime.now();
    // Compare against current month and year
    if (year < now.year || (year == now.year && month < now.month)) {
      return 'Card is expired';
    }

    return null;
  }
}