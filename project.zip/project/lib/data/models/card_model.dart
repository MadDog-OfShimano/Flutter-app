class CardModel {
  final String id;
  final String userId;
  final String cardNumberHash;
  final String maskedNumber;
  final String expiryDate;
  final String cardType;
  final bool isOnlineEnabled;

  CardModel({
    required this.id,
    required this.userId,
    required this.cardNumberHash,
    required this.maskedNumber,
    required this.expiryDate,
    required this.cardType,
    this.isOnlineEnabled = true,
  });

  factory CardModel.fromMap(Map<String, dynamic> json) => CardModel(
    id: json['id'] as String,
    userId: json['user_id'] as String,
    cardNumberHash: json['card_number_hash'] as String,
    maskedNumber: json['masked_number'] as String,
    expiryDate: json['expiry_date'] as String,
    cardType: json['card_type'] as String,
    isOnlineEnabled: json['is_online_enabled'] == 1,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'user_id': userId,
    'card_number_hash': cardNumberHash,
    'masked_number': maskedNumber,
    'expiry_date': expiryDate,
    'card_type': cardType,
    'is_online_enabled': isOnlineEnabled ? 1 : 0,
  };
}