import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/notification_model.dart';

class NotificationDao {
  final _dbProvider = AppDatabase.instance;

  // INSERTS a new system alert or transaction receipt
  Future<int> insertNotification(NotificationModel notification) async {
    final db = await _dbProvider.database;
    return await db.insert(
      'notifications',
      notification.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // READS all notifications for the active user, ordered newest first
  Future<List<NotificationModel>> getNotificationsByUserId(
    String userId,
  ) async {
    final db = await _dbProvider.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'notifications',
      where: 'user_id = ?',
      whereArgs: [userId],
      orderBy: 'created_at DESC',
    );

    return maps.map((map) => NotificationModel.fromMap(map)).toList();
  }

  // UPDATES a specific notification to 'read' status
  Future<int> markAsRead(String notificationId) async {
    final db = await _dbProvider.database;
    return await db.update(
      'notifications',
      {'is_read': 1},
      where: 'id = ?',
      whereArgs: [notificationId],
    );
  }
}
