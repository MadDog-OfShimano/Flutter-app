import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'notifications_provider.dart';
import '../../../data/models/notification_model.dart';

class NotificationsScreen extends StatelessWidget {
  const NotificationsScreen({super.key});

  // HELPER 1: Translates the SQLite string into a visual Icon
  IconData _getIconForType(String type) {
    switch (type) {
      case 'SECURITY':
        return Icons.security;
      case 'TRANSACTION':
        return Icons.receipt_long;
      case 'PROMOTIONAL':
        return Icons.local_offer;
      case 'SYSTEM':
      default:
        return Icons.info_outline;
    }
  }

  // HELPER 2: Translates the SQLite string into an Icon Color
  Color _getColorForType(String type) {
    switch (type) {
      case 'SECURITY':
        return Colors.red;
      case 'TRANSACTION':
        return Colors.green;
      case 'PROMOTIONAL':
        return Colors.purple;
      case 'SYSTEM':
      default:
        return const Color(0xFF0A2540); // Standard bank blue
    }
  }

  // HELPER 3: Formats the raw ISO8601 string from the database into a readable date
  String _formatDate(String isoString) {
    try {
      final date = DateTime.parse(isoString);
      return "${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')} ${date.hour.toString().padLeft(2, '0')}:${date.minute.toString().padLeft(2, '0')}";
    } catch (e) {
      return isoString; // Fallback if parsing fails
    }
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<NotificationsProvider>(context);
    final notifications = provider.filteredNotifications;

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text(
          "Inbox",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: Column(
        children: [
          // THE FILTER CONTROLS
          Container(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            color: Colors.white,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                _buildFilterChip(
                  context,
                  "All",
                  NotificationFilter.all,
                  provider,
                ),
                _buildFilterChip(
                  context,
                  "Important",
                  NotificationFilter.noPromotional,
                  provider,
                ),
                _buildFilterChip(
                  context,
                  "None",
                  NotificationFilter.none,
                  provider,
                ),
              ],
            ),
          ),
          const Divider(height: 1, thickness: 1),

          // THE LIST OF ALERTS
          Expanded(
            child: notifications.isEmpty
                ? const Center(
                    child: Text(
                      "No notifications found.",
                      style: TextStyle(color: Colors.grey),
                    ),
                  )
                : ListView.builder(
                    itemCount: notifications.length,
                    itemBuilder: (context, index) {
                      final note = notifications[index];
                      final isUnread = !note.isRead;

                      return Container(
                        margin: const EdgeInsets.symmetric(
                          horizontal: 16,
                          vertical: 8,
                        ),
                        decoration: BoxDecoration(
                          color: isUnread
                              ? Colors.blue.withOpacity(0.05)
                              : Colors.white,
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(
                            color: isUnread
                                ? Colors.blue.withOpacity(0.3)
                                : Colors.grey[200]!,
                          ),
                        ),
                        child: ListTile(
                          contentPadding: const EdgeInsets.all(16),
                          leading: CircleAvatar(
                            backgroundColor: _getColorForType(
                              note.notificationType,
                            ).withOpacity(0.1),
                            child: Icon(
                              _getIconForType(note.notificationType),
                              color: _getColorForType(note.notificationType),
                            ),
                          ),
                          title: Row(
                            mainAxisAlignment: MainAxisAlignment.spaceBetween,
                            children: [
                              Expanded(
                                child: Text(
                                  note.title,
                                  style: TextStyle(
                                    fontWeight: isUnread
                                        ? FontWeight.bold
                                        : FontWeight.w600,
                                    fontSize: 16,
                                  ),
                                ),
                              ),
                              if (isUnread)
                                Container(
                                  width: 8,
                                  height: 8,
                                  decoration: const BoxDecoration(
                                    color: Colors.blue,
                                    shape: BoxShape.circle,
                                  ),
                                ),
                            ],
                          ),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              const SizedBox(height: 8),
                              Text(
                                note.message,
                                style: TextStyle(
                                  color: Colors.grey[700],
                                  height: 1.4,
                                ),
                              ),
                              const SizedBox(height: 12),
                              Text(
                                _formatDate(note.createdAt),
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: Colors.grey,
                                ),
                              ),
                            ],
                          ),
                          onTap: () {
                            if (isUnread) {
                              provider.markAsRead(note.id);
                            }
                          },
                        ),
                      );
                    },
                  ),
          ),
        ],
      ),
    );
  }

  // UI component for the filter buttons
  Widget _buildFilterChip(
    BuildContext context,
    String label,
    NotificationFilter filter,
    NotificationsProvider provider,
  ) {
    final isSelected = provider.currentFilter == filter;
    return FilterChip(
      label: Text(label),
      selected: isSelected,
      onSelected: (_) => provider.updateFilter(filter),
      selectedColor: const Color(0xFF0A2540).withOpacity(0.1),
      checkmarkColor: const Color(0xFF0A2540),
      labelStyle: TextStyle(
        color: isSelected ? const Color(0xFF0A2540) : Colors.grey[600],
        fontWeight: isSelected ? FontWeight.bold : FontWeight.normal,
      ),
    );
  }
}
//AAAAAAAAAAAAAAAAAAAAA IM BOREDDDDDDDDASDADADAQWDFQFDQFQFwHBE2