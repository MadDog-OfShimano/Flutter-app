import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

// 1. The Correct Router Import
import 'core/network/app_router.dart';

// 2. The Correct Feature Provider Imports
import 'features/auth/presentation/auth_provider.dart';
import 'features/account/presentation/account_provider.dart';
import 'features/cards/presentation/cards_provider.dart';
import 'features/transactions/presentation/transactions_provider.dart';
import 'features/transfers/presentation/transfers_provider.dart'; // From our SQLite update
import 'features/settings/presentation/settings_provider.dart';
import 'features/notifications/presentation/notifications_provider.dart'; // Corrected Inbox name
import 'features/admin/presentation/admin_provider.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const SecureBankApp());
}

class SecureBankApp extends StatelessWidget {
  const SecureBankApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AuthProvider()),
        ChangeNotifierProvider(create: (_) => AccountProvider()),
        ChangeNotifierProvider(create: (_) => CardsProvider()),
        ChangeNotifierProvider(create: (_) => TransactionsProvider()),
        ChangeNotifierProvider(create: (_) => TransferProvider()),
        ChangeNotifierProvider(create: (_) => SettingsProvider()),
        ChangeNotifierProvider(create: (_) => NotificationsProvider()),
        ChangeNotifierProvider(create: (_) => AdminProvider()),
      ],
      child: MaterialApp.router(
        title: 'Secure Mobile Bank',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          primaryColor: const Color(0xFF0A2540),
          colorScheme: ColorScheme.fromSeed(seedColor: Colors.blueGrey),
        ),
        // 3. The Correct Router Instance Variable
        routerConfig: appRouter,
      ),
    );
  }
}
