import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/transaction_model.dart';

class TransactionDao {
  final _dbProvider = AppDatabase.instance;

  // Uses a SQL Transaction to ensure both the ledger insertion and balance update succeed together
  Future<void> executeTransfer(TransactionModel transaction, String senderId, double newBalance) async {
    final db = await _dbProvider.database;

    await db.transaction((txn) async {
      // 1. Record the transaction
      await txn.insert('transactions', transaction.toMap());

      // 2. Deduct the balance from the sender's user row
      await txn.update(
        'users',
        {'balance': newBalance},
        where: 'id = ?',
        whereArgs: [senderId],
      );
    });
  }

  // Fetch all transactions where the user is either the sender or receiver
  Future<List<TransactionModel>> getHistoryByIban(String iban) async {
    final db = await _dbProvider.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'transactions',
      where: 'sender_iban = ? OR receiver_iban = ?',
      whereArgs: [iban, iban],
      orderBy: 'created_at DESC', // Newest first
    );

    return maps.map((map) => TransactionModel.fromMap(map)).toList();
  }
}