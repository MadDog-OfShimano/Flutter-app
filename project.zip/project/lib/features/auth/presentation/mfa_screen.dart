import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../cards/presentation/cards_provider.dart';
import '../../transfers/presentation/transfers_provider.dart';
import '../../notifications/presentation/notifications_provider.dart';
import '../../account/presentation/account_provider.dart';
import 'auth_provider.dart';

class MfaScreen extends StatefulWidget {
  const MfaScreen({super.key});

  @override
  State<MfaScreen> createState() => _MfaScreenState();
}

class _MfaScreenState extends State<MfaScreen> {
  final _codeController = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  void _verifyCode() async {
    if (_formKey.currentState!.validate()) {
      final authProvider = Provider.of<AuthProvider>(context, listen: false);

      if (authProvider.isAuthenticated) {
        final userId = authProvider.currentUser!.id;
        final userIban = authProvider.currentUser!.iban;

        // Initializing downstream database streams
        if (context.mounted) {
          await Provider.of<CardsProvider>(
            context,
            listen: false,
          ).loadUserCards(userId);
          await Provider.of<TransferProvider>(
            context,
            listen: false,
          ).loadLedger(userIban);

          await Provider.of<NotificationsProvider>(
            context,
            listen: false,
          ).loadUserNotifications(userId);

          await Provider.of<AccountProvider>(
            context,
            listen: false,
          ).loadUserData(userId);

          await Provider.of<CardsProvider>(
            context,
            listen: false,
          ).loadUserCards(userId);
          await Provider.of<TransferProvider>(
            context,
            listen: false,
          ).loadLedger(userIban);
          await Provider.of<NotificationsProvider>(
            context,
            listen: false,
          ).loadUserNotifications(userId);

          context.go('/account');
        }
      }
    }
  }

  @override
  void dispose() {
    _codeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      appBar: AppBar(
        title: const Text(
          "Two-Factor Authentication",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 16),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(24.0),
        child: Form(
          key: _formKey,
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Icon(Icons.security, size: 64, color: Color(0xFF0A2540)),
              const SizedBox(height: 24),
              const Text(
                "Enter Verification Code",
                textAlign: TextAlign.center,
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                  color: Color(0xFF0A2540),
                ),
              ),
              const SizedBox(height: 8),
              Text(
                "Please enter the 6-digit code from your authenticator app to complete the login sequence.",
                textAlign: TextAlign.center,
                style: TextStyle(color: Colors.grey[600]),
              ),
              const SizedBox(height: 32),
              TextFormField(
                controller: _codeController,
                keyboardType: TextInputType.number,
                textAlign: TextAlign.center,
                maxLength: 6,
                style: const TextStyle(
                  fontSize: 24,
                  letterSpacing: 8,
                  fontWeight: FontWeight.bold,
                ),
                decoration: InputDecoration(
                  counterText: "",
                  border: OutlineInputBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                validator: (val) => (val == null || val.length != 6)
                    ? "Enter all 6 digits"
                    : null,
              ),
              const SizedBox(height: 32),
              ElevatedButton(
                onPressed: _verifyCode,
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF0A2540),
                  foregroundColor: Colors.white,
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8),
                  ),
                ),
                child: const Text(
                  "Verify Device",
                  style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
