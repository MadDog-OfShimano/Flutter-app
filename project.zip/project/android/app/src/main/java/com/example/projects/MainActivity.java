package com.example.projects; // This MUST match your folder path exactly!

import io.flutter.embedding.android.FlutterFragmentActivity;

public class MainActivity extends FlutterFragmentActivity {
}