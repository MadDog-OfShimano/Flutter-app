import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../../core/utils/luhn_validator.dart';
import 'cards_provider.dart';
import '../../../data/models/card_model.dart'; // Import the new SQLite model

class CardsScreen extends StatefulWidget {
  const CardsScreen({super.key});

  @override
  State<CardsScreen> createState() => _CardsScreenState();
}

class _CardsScreenState extends State<CardsScreen> {
  final PageController _pageController = PageController(viewportFraction: 0.85);

  final _addCardFormKey = GlobalKey<FormState>();
  final _cardNumberController = TextEditingController();
  final _expiryController = TextEditingController();

  @override
  void dispose() {
    _pageController.dispose();
    _cardNumberController.dispose();
    _expiryController.dispose();
    super.dispose();
  }

  void _promptSecurityCheck(CardModel card, bool intendedStatus) {
    final passwordController = TextEditingController();
    bool obscure = true;

    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setState) => AlertDialog(
          title: const Text("Security Verification", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text("Enter your account password to ${intendedStatus ? 'enable' : 'disable'} online purchases for card ending in ${card.maskedNumber.substring(card.maskedNumber.length - 4)}.", style: TextStyle(fontSize: 13, color: Colors.grey[700])),
              const SizedBox(height: 16),
              TextField(
                controller: passwordController,
                obscureText: obscure,
                decoration: InputDecoration(
                  labelText: "Password",
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(obscure ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => obscure = !obscure),
                  ),
                ),
              ),
            ],
          ),
          actions: [
            TextButton(onPressed: () => Navigator.pop(context), child: const Text("Cancel")),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0A2540), foregroundColor: Colors.white),
              onPressed: () async {
                // FIXED: Now awaits the asynchronous SQLite update
                bool success = await Provider.of<CardsProvider>(context, listen: false)
                    .toggleOnlinePurchases(card.id, intendedStatus, passwordController.text);

                if (!context.mounted) return;
                Navigator.pop(context);

                if (success) {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Settings updated in database."), backgroundColor: Colors.green));
                } else {
                  ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Invalid Password."), backgroundColor: Colors.red));
                }
              },
              child: const Text("Confirm"),
            ),
          ],
        ),
      ),
    );
  }

  void _showAddCardSheet() {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(20))),
      builder: (context) => Padding(
        padding: EdgeInsets.only(bottom: MediaQuery.of(context).viewInsets.bottom, top: 24, left: 24, right: 24),
        child: Form(
          key: _addCardFormKey,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              const Text("Link New Debit Card", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Color(0xFF0A2540))),
              const SizedBox(height: 24),
              TextFormField(
                controller: _cardNumberController,
                keyboardType: TextInputType.number,
                maxLength: 19,
                decoration: const InputDecoration(labelText: "Card Number", border: OutlineInputBorder(), counterText: ""),
                validator: LuhnValidator.validateCardNumber,
              ),
              const SizedBox(height: 16),
              TextFormField(
                controller: _expiryController,
                keyboardType: TextInputType.datetime,
                maxLength: 5,
                decoration: const InputDecoration(labelText: "Expiry Date (MM/YY)", border: OutlineInputBorder(), counterText: ""),
                validator: LuhnValidator.validateExpiryDate,
              ),
              const SizedBox(height: 24),
              ElevatedButton(
                style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0A2540), foregroundColor: Colors.white, padding: const EdgeInsets.symmetric(vertical: 16)),
                onPressed: () async {
                  if (_addCardFormKey.currentState!.validate()) {
                    // FIXED: Await the database insertion and handle the specific string result
                    final result = await Provider.of<CardsProvider>(context, listen: false)
                        .addCard(_cardNumberController.text, _expiryController.text, 'DEBIT');

                    if (!context.mounted) return;
                    Navigator.pop(context);
                    _cardNumberController.clear();
                    _expiryController.clear();

                    if (result == 'SUCCESS') {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Card Successfully Linked!"), backgroundColor: Colors.green));
                    } else if (result == 'DUPLICATE') {
                      // Physically reacting to the SQLite Unique Constraint violation
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Application Rejected: Card already exists in system."), backgroundColor: Colors.red));
                    } else {
                      ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Database Error."), backgroundColor: Colors.red));
                    }
                  }
                },
                child: const Text("Verify & Add Card"),
              ),
              const SizedBox(height: 24),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<CardsProvider>(context);

    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text("Card Management", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20)),
        backgroundColor: Colors.transparent,
        elevation: 0,
        actions: [
          IconButton(icon: const Icon(Icons.add_circle_outline, size: 28, color: Color(0xFF0A2540)), onPressed: _showAddCardSheet),
        ],
      ),
      body: provider.cards.isEmpty
          ? const Center(child: Text("No cards available."))
          : Column(
        children: [
          const SizedBox(height: 20),
          SizedBox(
            height: 220,
            child: PageView.builder(
              controller: _pageController,
              onPageChanged: provider.updateActiveIndex,
              itemCount: provider.cards.length,
              itemBuilder: (context, index) {
                return _buildCardVector(provider.cards[index], index == provider.activeCardIndex);
              },
            ),
          ),
          const SizedBox(height: 32),
          Expanded(
            child: Container(
              padding: const EdgeInsets.all(24),
              decoration: const BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.vertical(top: Radius.circular(30)),
                boxShadow: [BoxShadow(color: Colors.black12, blurRadius: 10, spreadRadius: 1)],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text("SECURITY PREFERENCES", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey, letterSpacing: 1)),
                  const SizedBox(height: 16),
                  SwitchListTile(
                    contentPadding: EdgeInsets.zero,
                    title: const Text("Online Purchases", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 15)),
                    subtitle: const Text("Allow transactions on the internet", style: TextStyle(fontSize: 12, color: Colors.grey)),
                    value: provider.activeCard!.isOnlineEnabled,
                    activeColor: const Color(0xFF0A2540),
                    onChanged: (value) => _promptSecurityCheck(provider.activeCard!, value),
                  ),
                  const Divider(),
                  ListTile(
                    contentPadding: EdgeInsets.zero,
                    leading: const Icon(Icons.delete_forever, color: Colors.red),
                    title: const Text("Delete Card / Revoke", style: TextStyle(fontWeight: FontWeight.bold, color: Colors.red, fontSize: 15)),
                    onTap: () => provider.deleteCard(provider.activeCard!.id),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildCardVector(CardModel card, bool isActive) {
    List<Color> gradientColors;

    switch (card.cardType) {
      case 'DEBIT':
        gradientColors = [const Color(0xFF0A2540), const Color(0xFF1E3C5C)];
        break;
      case 'CREDIT':
        gradientColors = [const Color(0xFFB8860B), const Color(0xFFDAA520)];
        break;
      default:
        gradientColors = [const Color(0xFF4B0082), const Color(0xFF8A2BE2)];
        break;
    }

    return AnimatedScale(
      scale: isActive ? 1.0 : 0.9,
      duration: const Duration(milliseconds: 300),
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 10, vertical: 10),
        padding: const EdgeInsets.all(24),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          gradient: LinearGradient(colors: gradientColors, begin: Alignment.topLeft, end: Alignment.bottomRight),
          boxShadow: [BoxShadow(color: gradientColors[0].withOpacity(0.4), blurRadius: 15, offset: const Offset(0, 8))],
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Icon(Icons.contactless, color: Colors.white70, size: 28),
                Text(card.cardType, style: const TextStyle(color: Colors.white70, fontWeight: FontWeight.bold, letterSpacing: 2)),
              ],
            ),
            const SizedBox(height: 10),
            Text(
              card.maskedNumber, // FIXED: Using the SQLite masked string directly
              style: const TextStyle(color: Colors.white, fontSize: 22, fontFamily: 'Courier', fontWeight: FontWeight.bold, letterSpacing: 2),
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: const [
                    Text("CARDHOLDER", style: TextStyle(color: Colors.white54, fontSize: 10, letterSpacing: 1)),
                    Text("AUTHORIZED USER", style: TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ],
                ),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text("VALID THRU", style: TextStyle(color: Colors.white54, fontSize: 10, letterSpacing: 1)),
                    Text(card.expiryDate, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.bold, letterSpacing: 1)),
                  ],
                ),
              ],
            )
          ],
        ),
      ),
    );
  }
}