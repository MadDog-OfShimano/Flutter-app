import 'package:flutter/material.dart';
import '../../../core/utils/iban_validator.dart';

class TransfersScreen extends StatefulWidget {
  const TransfersScreen({super.key});

  @override
  State<TransfersScreen> createState() => _TransfersScreenState();
}

class _TransfersScreenState extends State<TransfersScreen>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;
  final _formKey = GlobalKey<FormState>();
  final _ibanController = TextEditingController();
  final _amountController = TextEditingController();

  // Mock transfer history list data (Kept abstract from database for now)
  final List<Map<String, String>> _mockHistory = [
    {
      "name": "Ahmet Yılmaz",
      "iban": "TR560006200000012345678901",
      "amount": "-1,250.00 TL",
      "date": "12 June 2026",
    },
    {
      "name": "Sarah Connor",
      "iban": "TR120004400000098765432109",
      "amount": "+4,800.00 TL",
      "date": "08 June 2026",
    },
    {
      "name": "Fatima Al-Sayed",
      "iban": "TR890001000000055554444333",
      "amount": "-350.00 TL",
      "date": "01 June 2026",
    },
  ];

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: 2,
      vsync: this,
    ); // 2 tabs: History & Send
  }

  void _executeTransfer() {
    if (_formKey.currentState!.validate()) {
      // ABSTRACT: This is where our SQL/Backend transaction calls will go later!
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            'Processing transfer of ${_amountController.text} TL...',
          ),
          backgroundColor: Colors.green,
        ),
      );
      _ibanController.clear();
      _amountController.clear();
    }
  }

  @override
  void dispose() {
    _tabController.dispose();
    _ibanController.dispose();
    _amountController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text(
          "Money Transfers",
          style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20),
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
        bottom: TabBar(
          controller: _tabController,
          labelColor: const Color(0xFF0A2540),
          unselectedLabelColor: Colors.grey,
          indicatorColor: const Color(0xFF0A2540),
          indicatorWeight: 3,
          tabs: const [
            Tab(text: "Transfer Money"),
            Tab(text: "Transfer History"),
          ],
        ),
      ),
      body: TabBarView(
        controller: _tabController,
        children: [
          // TAB 1: TRANSFER MONEY FORM
          SingleChildScrollView(
            padding: const EdgeInsets.all(24.0),
            child: Form(
              key: _formKey,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  const Text(
                    "Send via Turkish IBAN Register",
                    style: TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.bold,
                      color: Color(0xFF0A2540),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Recipient IBAN Input Box with Inline Validation
                  TextFormField(
                    controller: _ibanController,
                    maxLength: 34, // Accommodates spaces easily while typing
                    keyboardType: TextInputType.text,
                    textCapitalization: TextCapitalization.characters,
                    decoration: const InputDecoration(
                      labelText: "Recipient IBAN",
                      hintText: "TR00 0000 0000...",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.account_balance_wallet_outlined),
                      counterText:
                          "", // Hides length counter for cleaner aesthetic
                    ),
                    // Runs our specialized MOD97 validation code directly!
                    validator: IbanValidator.validateTurkishIban,
                  ),
                  const SizedBox(height: 20),

                  // Amount Input Box
                  TextFormField(
                    controller: _amountController,
                    keyboardType: const TextInputType.numberWithOptions(
                      decimal: true,
                    ),
                    decoration: const InputDecoration(
                      labelText: "Amount (TL)",
                      hintText: "0.00",
                      border: OutlineInputBorder(),
                      prefixIcon: Icon(Icons.toll_outlined),
                    ),
                    validator: (val) =>
                        (val == null ||
                            val.isEmpty ||
                            double.tryParse(val) == null ||
                            double.parse(val) <= 0)
                        ? "Please enter a valid transfer amount."
                        : null,
                  ),
                  const SizedBox(height: 32),

                  // Submit Action Button
                  ElevatedButton(
                    onPressed: _executeTransfer,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: const Color(0xFF0A2540),
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 16),
                      shape: RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(8),
                      ),
                    ),
                    child: const Text(
                      "Confirm & Send Funds",
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),

          // TAB 2: TRANSFER HISTORY LIST
          ListView.separated(
            padding: const EdgeInsets.all(24.0),
            itemCount: _mockHistory.length,
            separatorBuilder: (context, index) => const SizedBox(height: 12),
            itemBuilder: (context, index) {
              final transaction = _mockHistory[index];
              final isNegative = transaction['amount']!.startsWith('-');

              return Card(
                elevation: 0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(12),
                  side: BorderSide(color: Colors.grey[200]!),
                ),
                child: ListTile(
                  leading: CircleAvatar(
                    backgroundColor: isNegative
                        ? Colors.red[50]
                        : Colors.green[50],
                    child: Icon(
                      isNegative
                          ? Icons.arrow_outward_rounded
                          : Icons.call_received_rounded,
                      color: isNegative ? Colors.red : Colors.green,
                    ),
                  ),
                  title: Text(
                    transaction['name']!,
                    style: const TextStyle(fontWeight: FontWeight.bold),
                  ),
                  subtitle: Text(
                    transaction['iban']!.replaceAllMapped(
                      RegExp(r'.{4}'),
                      (match) => '${match.group(0)} ',
                    ),
                    style: const TextStyle(
                      fontSize: 11,
                      fontFamily: 'Courier',
                      overflow: TextOverflow.ellipsis,
                    ),
                  ),
                  trailing: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        transaction['amount']!,
                        style: TextStyle(
                          fontWeight: FontWeight.bold,
                          fontSize: 15,
                          color: isNegative
                              ? Colors.red[700]
                              : Colors.green[700],
                        ),
                      ),
                      Text(
                        transaction['date']!,
                        style: TextStyle(color: Colors.grey[500], fontSize: 11),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}
