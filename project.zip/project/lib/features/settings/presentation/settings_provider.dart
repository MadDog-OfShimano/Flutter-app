import 'package:flutter/material.dart';

class SettingsProvider extends ChangeNotifier {
  // Default values based on your blueprint
  bool _isDarkMode = false;
  String _currentLanguage = 'English';
  double _textScale = 1.0;

  // Getters
  bool get isDarkMode => _isDarkMode;
  String get currentLanguage => _currentLanguage;
  double get textScale => _textScale;

  // Setters
  void toggleTheme(bool value) {
    _isDarkMode = value;
    notifyListeners();
  }

  void changeLanguage(String newLanguage) {
    if (_currentLanguage == newLanguage) return;
    _currentLanguage = newLanguage;
    notifyListeners();
  }

  void updateTextScale(double newScale) {
    _textScale = newScale;
    notifyListeners();
  }
}