import '../dao/transaction_dao.dart';
import '../models/transaction_model.dart';
import 'package:uuid/uuid.dart';

class TransactionRepository {
  final TransactionDao _transactionDao = TransactionDao();
  final _uuid = const Uuid();

  Future<bool> sendMoney({
    required String senderId,
    required String senderIban,
    required String receiverIban,
    required double amount,
    required double currentBalance,
    String? note,
  }) async {
    if (currentBalance < amount) return false; // Insufficient funds

    final newTx = TransactionModel(
      id: _uuid.v4(),
      senderIban: senderIban,
      receiverIban: receiverIban,
      amount: amount,
      transactionType: 'TRANSFER',
      referenceNote: note,
      createdAt: DateTime.now().toIso8601String(),
    );

    final newBalance = currentBalance - amount;

    try {
      await _transactionDao.executeTransfer(newTx, senderId, newBalance);
      return true;
    } catch (e) {
      return false;
    }
  }

  Future<List<TransactionModel>> fetchLedger(String iban) async {
    return await _transactionDao.getHistoryByIban(iban);
  }
}