import 'package:http/http.dart' as http;
import 'dart:convert';
import '../../../core/security/biometric_service.dart';

class AuthRepository {
  final String baseUrl = "https://api.yourbank.com";
  final BiometricService _biometricService = BiometricService();

  /// Step 1: Send credentials to Backend. Returns an mfa_token_id if password matches.
  Future<Map<String, dynamic>> initiateLogin(
    String email,
    String password,
  ) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/auth/login'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'email': email, 'password': password}),
      );

      if (response.statusCode == 200) {
        return jsonDecode(response.body);
      } else {
        throw Exception(
          jsonDecode(response.body)['message'] ?? 'Failed to authenticate.',
        );
      }
    } catch (e) {
      throw Exception('Network error: Could not reach the server.');
    }
  }

  /// Step 2: Verify 6-digit OTP code. If success, save long-lived Refresh Token to hardware.
  Future<bool> verifyMfa(String mfaTokenId, String otpCode) async {
    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/auth/verify-mfa'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'mfa_token_id': mfaTokenId, 'otp_code': otpCode}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);

        // Extract tokens from backend response
        String accessToken = data['access_token'];
        String refreshToken = data['refresh_token'];

        // Securely write the long-lived refresh token directly into the device's secure enclave
        await _biometricService.saveSecureToken(refreshToken);

        return true;
      } else {
        throw Exception(
          jsonDecode(response.body)['message'] ?? 'Invalid MFA code.',
        );
      }
    } catch (e) {
      throw Exception('Network error during verification.');
    }
  }

  /// Step 3: Silent Refresh using the stored secure token (Used when Biometrics pass)
  Future<String?> attemptSilentRefresh() async {
    final savedRefreshToken = await _biometricService.getSecureToken();
    if (savedRefreshToken == null) return null;

    try {
      final response = await http.post(
        Uri.parse('$baseUrl/api/auth/refresh'),
        headers: {'Content-Type': 'application/json'},
        body: jsonEncode({'refresh_token': savedRefreshToken}),
      );

      if (response.statusCode == 200) {
        final data = jsonDecode(response.body);
        return data['access_token']; // Return fresh short-lived JWT token
      } else {
        // Stale token or revoked session: clear it out
        await _biometricService.clearSecureToken();
        return null;
      }
    } catch (_) {
      return null; // Silent failure keeps user on login screen safely
    }
  }
}
