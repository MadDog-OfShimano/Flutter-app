import 'package:flutter/material.dart';
import '../../../data/repositories/transaction_repository.dart';
import '../../../data/models/transaction_model.dart';

class TransferProvider extends ChangeNotifier {
  final TransactionRepository _transactionRepo = TransactionRepository();
  List<TransactionModel> _transactions = [];
  bool _isLoading = false;

  List<TransactionModel> get transactions => _transactions;
  bool get isLoading => _isLoading;

  Future<void> loadLedger(String iban) async {
    _isLoading = true;
    notifyListeners();

    _transactions = await _transactionRepo.fetchLedger(iban);

    _isLoading = false;
    notifyListeners();
  }

  Future<bool> executeLocalTransfer({
    required String senderId,
    required String senderIban,
    required String receiverIban,
    required double amount,
    required double currentBalance,
    String? note,
  }) async {
    final success = await _transactionRepo.sendMoney(
      senderId: senderId,
      senderIban: senderIban,
      receiverIban: receiverIban,
      amount: amount,
      currentBalance: currentBalance,
      note: note,
    );

    if (success) {
      await loadLedger(senderIban); // Dynamically reload history from SQLite
    }
    return success;
  }
}