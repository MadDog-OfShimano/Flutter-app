import 'package:flutter/material.dart';
import '../../../data/dao/notification_dao.dart';
import '../../../data/models/notification_model.dart';

enum NotificationFilter { all, none, noPromotional }

enum NotificationType { security, transaction, promotional, system }

// Abstract model mimicking a backend push notification payload
class NotificationRecord {
  final String id;
  final String title;
  final String message;
  final DateTime timestamp;
  final NotificationType type;
  bool isRead;

  NotificationRecord({
    required this.id,
    required this.title,
    required this.message,
    required this.timestamp,
    required this.type,
    this.isRead = false,
  });
}

class NotificationsProvider extends ChangeNotifier {
  final NotificationDao _notificationDao = NotificationDao();
  List<NotificationModel> _allNotifications = [];
  NotificationFilter _currentFilter = NotificationFilter.all;
  String? _currentUserId;

  NotificationFilter get currentFilter => _currentFilter;

  Future<void> loadUserNotifications(String userId) async {
    _currentUserId = userId;
    _allNotifications = await _notificationDao.getNotificationsByUserId(userId);
    notifyListeners();
  }

  // Applies the radio button rules dynamically to the SQLite data
  List<NotificationModel> get filteredNotifications {
    if (_currentFilter == NotificationFilter.none) {
      return [];
    } else if (_currentFilter == NotificationFilter.noPromotional) {
      return _allNotifications
          .where((n) => n.notificationType != 'PROMOTIONAL')
          .toList();
    }
    return _allNotifications;
  }

  void updateFilter(NotificationFilter filter) {
    _currentFilter = filter;
    notifyListeners();
  }

  Future<void> markAsRead(String id) async {
    await _notificationDao.markAsRead(id);
    if (_currentUserId != null) {
      await loadUserNotifications(
        _currentUserId!,
      ); // Refresh to show UI changes
    }
  }
}
