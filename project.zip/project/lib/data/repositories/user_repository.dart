import '../dao/user_dao.dart';
import '../models/user_model.dart';
import 'package:uuid/uuid.dart';
import 'package:crypto/crypto.dart';
import '../dao/notification_dao.dart';
import '../models/notification_model.dart';
import 'dart:convert';


class UserRepository {
  final UserDao _userDao = UserDao();
  final _uuid = const Uuid();

  // Helper function to hash passwords before they ever touch the DAO
  String _hashPassword(String password) {
    final bytes = utf8.encode(password);
    final digest = sha256.convert(bytes);
    return digest.toString();
  }

  Future<bool> registerNewUser({
    required String email,
    required String password,
    required String fullName,
    required String phoneNumber,
    required String idDocumentPath,
    required String generatedIban,
    
  }) async {
    try {
      final isBanned = await _userDao.isPhoneRejected(phoneNumber);
      if (isBanned) return false; // Triggers "Application Refused" in UI

      final newUser = UserModel(
        id: _uuid.v4(),
        email: email,
        passwordHash: _hashPassword(password),
        fullName: fullName,
        phoneNumber: phoneNumber,
        idDocumentPath: idDocumentPath,
        iban: generatedIban,
      );

      await _userDao.insertUser(newUser);

      // AUTOMATIC SYSTEM TRIGGER: Send a Welcome Notification
      final NotificationDao notifDao = NotificationDao();
      final welcomeAlert = NotificationModel(
        id: _uuid.v4(),
        userId: newUser.id,
        title: 'Welcome to Secure Bank',
        message: 'Your application has been received. You currently have limited access until an administrator verifies your ID document.',
        notificationType: 'SYSTEM',
        createdAt: DateTime.now().toIso8601String(),
      );
      await notifDao.insertNotification(welcomeAlert);

      return true;
    } catch (e) {
      // Catch duplicate emails or SQLite constraint errors
      return false;
    }
    
  }

  Future<UserModel?> authenticateUser(String email, String password) async {
    final user = await _userDao.getUserByEmail(email);

    if (user != null) {
      final inputHash = _hashPassword(password);
      if (user.passwordHash == inputHash) {
        return user; // Valid login
      }
    }
    return null; // Invalid credentials
  }

  Future<void> approveUserAccount(String userId) async {
    await _userDao.updateUserStatus(userId, 'ACTIVE');
  }
}
