import 'package:sqflite/sqflite.dart';
import 'package:path/path.dart';

class AppDatabase {
  // Singleton instance pattern
  static final AppDatabase instance = AppDatabase._init();
  static Database? _database;

  AppDatabase._init();

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDB('secure_bank.db');
    return _database!;
  }

  Future<Database> _initDB(String filePath) async {
    final dbPath = await getDatabasesPath();
    final path = join(dbPath, filePath);

    // Opens the database and triggers creation scripts if it doesn't exist
    return await openDatabase(path, version: 1, onCreate: _createDB);
  }

  Future _createDB(Database db, int version) async {
    // 1. Users Table (Auth, MFA, and Approval Status)
    await db.execute('''
      CREATE TABLE users (
        id TEXT PRIMARY KEY,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        mfa_enabled INTEGER DEFAULT 0, -- SQLite handles booleans as 0/1 integers
        mfa_secret TEXT,
        account_status TEXT DEFAULT 'PENDING_APPROVAL',
        full_name TEXT NOT NULL,
        phone_number TEXT UNIQUE NOT NULL,
        id_document_path TEXT NOT NULL,
        iban TEXT UNIQUE NOT NULL,
        balance REAL DEFAULT 0.00
      )
    ''');

    // 2. Cards Table (Stores masked data and hashed full sequence for constraint checking)
    await db.execute('''
      CREATE TABLE cards (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        card_number_hash TEXT UNIQUE NOT NULL, -- Core unique check requirement
        masked_number TEXT NOT NULL,
        expiry_date TEXT NOT NULL,
        card_type TEXT NOT NULL,
        is_online_enabled INTEGER DEFAULT 1,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
      )
    ''');

    // 3. Transactions Table (The relational financial ledger ledger)
    await db.execute('''
      CREATE TABLE transactions (
        id TEXT PRIMARY KEY,
        sender_iban TEXT NOT NULL,
        receiver_iban TEXT NOT NULL,
        amount REAL NOT NULL,
        transaction_type TEXT NOT NULL,
        category TEXT DEFAULT 'General',
        reference_note TEXT,
        created_at TEXT NOT NULL
      )
    ''');

    // 4. Notifications Table
    await db.execute('''
      CREATE TABLE notifications (
        id TEXT PRIMARY KEY,
        user_id TEXT NOT NULL,
        title TEXT NOT NULL,
        message TEXT NOT NULL,
        notification_type TEXT NOT NULL,
        is_read INTEGER DEFAULT 0,
        created_at TEXT NOT NULL,
        FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
      )
    '''); // 5. The Admin Table
    await db.execute('''
      CREATE TABLE admins (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL -- Storing plain text here just for the school project simplicity, or hash it!
      )
    ''');

    // Insert the default admin account immediately
    await db.execute('''
      INSERT INTO admins (id, username, password) 
      VALUES ('admin_01', 'admin', 'admin123')
    ''');

    // 6. The Rejected Applicants Table
    await db.execute('''
      CREATE TABLE rejected_applicants (
        phone_number TEXT PRIMARY KEY,
        rejected_at TEXT NOT NULL
      )
    ''');
  }

  Future close() async {
    final db = await instance.database;
    db.close();
  }
}
