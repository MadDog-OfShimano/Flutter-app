class TransactionModel {
  final String id;
  final String senderIban;
  final String receiverIban;
  final double amount;
  final String transactionType;
  final String category;
  final String? referenceNote;
  final String createdAt;

  TransactionModel({
    required this.id,
    required this.senderIban,
    required this.receiverIban,
    required this.amount,
    required this.transactionType,
    this.category = 'General',
    this.referenceNote,
    required this.createdAt,
  });

  factory TransactionModel.fromMap(Map<String, dynamic> json) => TransactionModel(
    id: json['id'] as String,
    senderIban: json['sender_iban'] as String,
    receiverIban: json['receiver_iban'] as String,
    amount: (json['amount'] as num).toDouble(),
    transactionType: json['transaction_type'] as String,
    category: json['category'] as String,
    referenceNote: json['reference_note'] as String?,
    createdAt: json['created_at'] as String,
  );

  Map<String, dynamic> toMap() => {
    'id': id,
    'sender_iban': senderIban,
    'receiver_iban': receiverIban,
    'amount': amount,
    'transaction_type': transactionType,
    'category': category,
    'reference_note': referenceNote,
    'created_at': createdAt,
  };
}