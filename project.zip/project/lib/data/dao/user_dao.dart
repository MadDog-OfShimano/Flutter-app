import 'package:sqflite/sqflite.dart';
import '../database/app_database.dart';
import '../models/user_model.dart';

class UserDao {
  final _dbProvider = AppDatabase.instance;

  // INSERTS a new row when someone uses the SignupScreen
  Future<int> insertUser(UserModel user) async {
    final db = await _dbProvider.database;
    // Uses the .toMap() function we wrote in UserModel to format the data
    return await db.insert(
      'users',
      user.toMap(),
      conflictAlgorithm: ConflictAlgorithm.replace,
    );
  }

  // READS a user by email for the LoginScreen
  Future<UserModel?> getUserByEmail(String email) async {
    final db = await _dbProvider.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'users',
      where: 'email = ?',
      whereArgs: [email],
    );

    if (maps.isNotEmpty) {
      return UserModel.fromMap(maps.first);
    }
    return null;
  }

  // READS all users currently waiting for Admin approval
  Future<List<UserModel>> getPendingUsers() async {
    final db = await _dbProvider.database;
    final List<Map<String, dynamic>> maps = await db.query(
      'users',
      where: 'account_status = ?',
      whereArgs: ['PENDING_APPROVAL'],
    );

    return maps.map((map) => UserModel.fromMap(map)).toList();
  }

  // UPDATES the status when an Admin approves a pending ID
  Future<int> updateUserStatus(String id, String newStatus) async {
    final db = await _dbProvider.database;
    return await db.update(
      'users',
      {'account_status': newStatus},
      where: 'id = ?',
      whereArgs: [id],
    );
  }

  // DELETES a user completely (Cascade will auto-delete their cards/transactions)
  Future<int> deleteUser(String id) async {
    final db = await _dbProvider.database;
    return await db.delete('users', where: 'id = ?', whereArgs: [id]);
  }

  // --- ADMIN AUTHENTICATION ---
  Future<bool> verifyAdmin(String username, String password) async {
    final db = await _dbProvider.database;
    final maps = await db.query(
      'admins',
      where: 'username = ? AND password = ?',
      whereArgs: [username, password],
    );
    return maps.isNotEmpty;
  }

  // --- REJECTION LOGIC ---
  Future<void> rejectAndBanUser(String userId, String phoneNumber) async {
    final db = await _dbProvider.database;
    await db.transaction((txn) async {
      // 1. Add to rejected list
      await txn.insert('rejected_applicants', {
        'phone_number': phoneNumber,
        'rejected_at': DateTime.now().toIso8601String(),
      });
      // 2. Delete the pending application
      await txn.delete('users', where: 'id = ?', whereArgs: [userId]);
    });
  }

  // Checks if a phone number is permanently banned
  Future<bool> isPhoneRejected(String phoneNumber) async {
    final db = await _dbProvider.database;
    final maps = await db.query(
      'rejected_applicants',
      where: 'phone_number = ?',
      whereArgs: [phoneNumber],
    );
    return maps.isNotEmpty;
  }

  // Fetches a single user by their ID for the live dashboard
  Future<UserModel?> getUserById(String id) async {
    final db = await _dbProvider.database;
    final maps = await db.query('users', where: 'id = ?', whereArgs: [id]);

    if (maps.isNotEmpty) {
      return UserModel.fromMap(maps.first);
    }
    return null;
  }

  // --- ACTIVE USERS LIST ---
  Future<List<UserModel>> getActiveUsers() async {
    final db = await _dbProvider.database;
    final maps = await db.query(
      'users',
      where: 'account_status = ?',
      whereArgs: ['ACTIVE'],
    );
    return maps.map((map) => UserModel.fromMap(map)).toList();
  }
}
