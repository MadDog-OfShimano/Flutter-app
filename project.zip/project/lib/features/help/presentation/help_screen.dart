import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';

class HelpScreen extends StatelessWidget {
  const HelpScreen({super.key});

  // NATIVE DIALER: Opens the phone's native calling app
  Future<void> _callSupport(BuildContext context) async {
    // Standard mock customer service number (Turkish format)
    final Uri phoneUri = Uri(scheme: 'tel', path: '+908501234567');

    try {
      if (await canLaunchUrl(phoneUri)) {
        await launchUrl(phoneUri);
      } else {
        throw 'Could not launch dialer';
      }
    } catch (e) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text("Error opening phone dialer. Please check device permissions."), backgroundColor: Colors.red),
        );
      }
    }
  }

  // DIALOG: Scrollable Terms of Service
  void _showTermsOfService(BuildContext context) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Terms of Service", style: TextStyle(fontWeight: FontWeight.bold)),
        content: SizedBox(
          width: double.maxFinite,
          child: ListView(
            shrinkWrap: true,
            children: const [
              Text(
                "1. Introduction\nWelcome to our banking application. By accessing or using our services, you agree to be bound by these Terms of Service.\n\n"
                    "2. Account Security\nYou are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.\n\n"
                    "3. Transactions\nAll transactions are subject to verification. We reserve the right to cancel or reverse any transaction that appears fraudulent.\n\n"
                    "4. Privacy\nYour privacy is important to us. Please review our Privacy Policy to understand how we collect, use, and share your information.\n\n"
                    "5. Modifications\nWe may modify these Terms at any time. Continued use of the app constitutes acceptance of the modified Terms.",
                style: TextStyle(fontSize: 14, height: 1.5),
              ),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: const Color(0xFF0A2540), foregroundColor: Colors.white),
            onPressed: () => Navigator.pop(context),
            child: const Text("I Understand"),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.grey[50],
      appBar: AppBar(
        title: const Text("Help & Support", style: TextStyle(fontWeight: FontWeight.bold, fontSize: 20, color: Color(0xFF0A2540))),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24.0),
        children: [
          // CONTACT SUPPORT SECTION
          const Text("CONTACT US", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey, letterSpacing: 1.2)),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey[200]!),
            ),
            child: Column(
              children: [
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.blue[50],
                    child: const Icon(Icons.phone_in_talk, color: Colors.blue),
                  ),
                  title: const Text("Call Customer Service", style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: const Text("Available 24/7", style: TextStyle(fontSize: 12)),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                  onTap: () => _callSupport(context),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: CircleAvatar(
                    backgroundColor: Colors.orange[50],
                    child: const Icon(Icons.email, color: Colors.orange),
                  ),
                  title: const Text("Send an Email", style: TextStyle(fontWeight: FontWeight.bold)),
                  subtitle: const Text("Response within 24 hours", style: TextStyle(fontSize: 12)),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                  onTap: () {
                    // Similar logic can be applied here using scheme: 'mailto'
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Email client routing goes here.")));
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 32),

          // LEGAL SECTION
          const Text("LEGAL", style: TextStyle(fontSize: 12, fontWeight: FontWeight.bold, color: Colors.grey, letterSpacing: 1.2)),
          const SizedBox(height: 12),
          Card(
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: Colors.grey[200]!),
            ),
            child: Column(
              children: [
                ListTile(
                  leading: const Icon(Icons.description_outlined, color: Color(0xFF0A2540)),
                  title: const Text("Terms of Service", style: TextStyle(fontWeight: FontWeight.w600)),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                  onTap: () => _showTermsOfService(context),
                ),
                const Divider(height: 1),
                ListTile(
                  leading: const Icon(Icons.privacy_tip_outlined, color: Color(0xFF0A2540)),
                  title: const Text("Privacy Policy", style: TextStyle(fontWeight: FontWeight.w600)),
                  trailing: const Icon(Icons.arrow_forward_ios, size: 16, color: Colors.grey),
                  onTap: () {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Privacy Policy document loading...")));
                  },
                ),
              ],
            ),
          ),

          const SizedBox(height: 48),

          // APP VERSION FOOTER
          Center(
            child: Column(
              children: [
                const Icon(Icons.account_balance, color: Colors.grey, size: 32),
                const SizedBox(height: 8),
                Text("Version 1.0.0 (Build 42)", style: TextStyle(color: Colors.grey[500], fontSize: 12)),
              ],
            ),
          )
        ],
      ),
    );
  }
}