import 'package:flutter/material.dart';
import '../../../data/repositories/card_repository.dart';
import '../../../data/models/card_model.dart';

class CardsProvider extends ChangeNotifier {
  final CardRepository _cardRepo = CardRepository();
  List<CardModel> _cards = [];
  int _activeCardIndex = 0;
  String? _currentUserId;

  List<CardModel> get cards => _cards;
  int get activeCardIndex => _activeCardIndex;
  CardModel? get activeCard => _cards.isNotEmpty ? _cards[_activeCardIndex] : null;

  Future<void> loadUserCards(String userId) async {
    _currentUserId = userId;
    _cards = await _cardRepo.fetchUserCards(userId);
    notifyListeners();
  }

  void updateActiveIndex(int index) {
    _activeCardIndex = index;
    notifyListeners();
  }

  Future<bool> toggleOnlinePurchases(String cardId, bool currentStatus, String confirmedPassword) async {
    // Note: In a full app, re-verify the password via UserRepository here
    if (confirmedPassword.length >= 6) {
      await _cardRepo.toggleOnlineStatus(cardId, currentStatus);
      await loadUserCards(_currentUserId!); // Refresh UI
      return true;
    }
    return false;
  }

  Future<String> addCard(String number, String expiry, String type) async {
    if (_currentUserId == null) return 'ERROR';

    final result = await _cardRepo.addCard(
      userId: _currentUserId!,
      rawCardNumber: number,
      expiryDate: expiry,
      cardType: type,
    );

    if (result == 'SUCCESS') {
      await loadUserCards(_currentUserId!);
    }
    return result; // Can be 'SUCCESS', 'DUPLICATE', or 'ERROR'
  }

  Future<void> deleteCard(String cardId) async {
    await _cardRepo.removeCard(cardId);
    _activeCardIndex = 0;
    await loadUserCards(_currentUserId!);
  }
}