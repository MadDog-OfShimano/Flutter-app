import 'package:flutter/material.dart';

// Abstract model mimicking a SQL Row
class TransactionRecord {
  final String id;
  final String title;
  final double amount; // Negative for purchases, positive for received
  final DateTime date;
  final String category;

  TransactionRecord({
    required this.id,
    required this.title,
    required this.amount,
    required this.date,
    required this.category,
  });
}

class TransactionsProvider extends ChangeNotifier {
  List<TransactionRecord> _allTransactions = [];
  String _selectedFilter = 'Year'; // 'Year' or 'Month'

  String get selectedFilter => _selectedFilter;
  List<TransactionRecord> get transactions => _allTransactions;

  void loadAbstractData() {
    if (_allTransactions.isNotEmpty) return;

    // MOCK SQL DATA: This represents what the backend would return from a query like:
    // SELECT * FROM transactions WHERE user_id = ? AND date >= ? ORDER BY date DESC
    final now = DateTime.now();
    _allTransactions = [
      TransactionRecord(
        id: '1',
        title: 'Migros Supermarket',
        amount: -450.50,
        date: now.subtract(const Duration(days: 2)),
        category: 'Groceries',
      ),
      TransactionRecord(
        id: '2',
        title: 'Salary Deposit',
        amount: 45000.00,
        date: now.subtract(const Duration(days: 5)),
        category: 'Income',
      ),
      TransactionRecord(
        id: '3',
        title: 'Netflix Subscription',
        amount: -149.99,
        date: now.subtract(const Duration(days: 15)),
        category: 'Entertainment',
      ),
      TransactionRecord(
        id: '4',
        title: 'Starbucks',
        amount: -85.00,
        date: now.subtract(const Duration(days: 40)),
        category: 'Food',
      ), // Last month
      TransactionRecord(
        id: '5',
        title: 'Steam Games',
        amount: -600.00,
        date: now.subtract(const Duration(days: 45)),
        category: 'Entertainment',
      ),
      TransactionRecord(
        id: '6',
        title: 'Freelance Design',
        amount: 8500.00,
        date: now.subtract(const Duration(days: 80)),
        category: 'Income',
      ), // 2 months ago
    ];
    notifyListeners();
  }

  void setFilter(String filter) {
    _selectedFilter = filter;
    notifyListeners();
  }

  // Calculates the total based on the active filter
  double calculateTotalSpending() {
    final now = DateTime.now();
    double total = 0;

    for (var tx in _allTransactions) {
      if (tx.amount < 0) {
        // Only sum up spending, not income
        if (_selectedFilter == 'Year' && tx.date.year == now.year) {
          total += tx.amount;
        } else if (_selectedFilter == 'Month' &&
            tx.date.month == now.month &&
            tx.date.year == now.year) {
          total += tx.amount;
        }
      }
    }
    return total.abs(); // Return positive number for display purposes
  }

  // Helper to group transactions into a Map sorted by Month-Year strings
  Map<String, List<TransactionRecord>> getGroupedTransactions() {
    Map<String, List<TransactionRecord>> grouped = {};
    for (var tx in _allTransactions) {
      String monthYear = "${_getMonthName(tx.date.month)} ${tx.date.year}";
      if (!grouped.containsKey(monthYear)) grouped[monthYear] = [];
      grouped[monthYear]!.add(tx);
    }
    return grouped;
  }

  String _getMonthName(int month) {
    const months = [
      'Jan',
      'Feb',
      'Mar',
      'Apr',
      'May',
      'Jun',
      'Jul',
      'Aug',
      'Sep',
      'Oct',
      'Nov',
      'Dec',
    ];
    return months[month - 1];
  }
}
