import 'package:flutter/services.dart';
import 'package:local_auth/local_auth.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class BiometricService {
  // Enforce singleton pattern so we only ever use one instance across the app
  static final BiometricService _instance = BiometricService._internal();
  factory BiometricService() => _instance;
  BiometricService._internal();

  final LocalAuthentication _auth = LocalAuthentication();
  final FlutterSecureStorage _secureStorage = const FlutterSecureStorage(
    // Android-specific security option ensuring backups don't leak encrypted keys
    aOptions: AndroidOptions(encryptedSharedPreferences: true),
  );

  static const String _tokenKey = "secure_refresh_token";

  /// 1. Check if hardware supports biometrics and the user has set it up
  Future<bool> isDeviceCapable() async {
    try {
      final bool canAuthenticateWithBiometrics = await _auth.canCheckBiometrics;
      final bool canAuthenticate =
          canAuthenticateWithBiometrics || await _auth.isDeviceSupported();
      final List<BiometricType> availableBiometrics = await _auth
          .getAvailableBiometrics();

      return canAuthenticate && availableBiometrics.isNotEmpty;
    } on PlatformException catch (_) {
      return false;
    }
  }

  /// 2. Trigger the OS native FaceID / Fingerprint prompt
  Future<bool> authenticateUser() async {
    try {
      final bool isCapable = await isDeviceCapable();
      if (!isCapable) return false;

      return await _auth.authenticate(
        localizedReason: 'Please authenticate to unlock your bank account',
        options: const AuthenticationOptions(
          stickyAuth:
              true, // Keeps prompt active if app temporarily goes to background
          biometricOnly:
              true, // Enforces biometric scan, bars device passcode fallback
        ),
      );
    } on PlatformException catch (_) {
      return false;
    }
  }

  /// 3. Save the backend Refresh Token into the hardware secure storage enclave
  Future<void> saveSecureToken(String token) async {
    await _secureStorage.write(key: _tokenKey, value: token);
  }

  /// 4. Read the Refresh Token out of secure storage
  Future<String?> getSecureToken() async {
    return await _secureStorage.read(key: _tokenKey);
  }

  /// 5. Clear secure storage (Call this on explicit User Logout)
  Future<void> clearSecureToken() async {
    await _secureStorage.delete(key: _tokenKey);
  }
}
