import 'package:flutter/material.dart';
import '../../../data/dao/user_dao.dart';
import '../../../data/models/user_model.dart';

class AdminProvider extends ChangeNotifier {
  final UserDao _userDao = UserDao();

  bool _isAdminAuthenticated = false;
  List<UserModel> _pendingUsers = [];
  List<UserModel> _activeUsers = [];

  bool get isAdminAuthenticated => _isAdminAuthenticated;
  List<UserModel> get pendingUsers => _pendingUsers;
  List<UserModel> get activeUsers => _activeUsers;

  Future<bool> loginAdmin(String username, String password) async {
    _isAdminAuthenticated = await _userDao.verifyAdmin(username, password);
    if (_isAdminAuthenticated) {
      await loadDashboardData();
    }
    notifyListeners();
    return _isAdminAuthenticated;
  }

  void logoutAdmin() {
    _isAdminAuthenticated = false;
    _pendingUsers.clear();
    _activeUsers.clear();
    notifyListeners();
  }

  Future<void> loadDashboardData() async {
    _pendingUsers = await _userDao.getPendingUsers();
    _activeUsers = await _userDao.getActiveUsers();
    notifyListeners();
  }

  Future<void> approveUser(String userId) async {
    await _userDao.updateUserStatus(userId, 'ACTIVE');
    await loadDashboardData();
  }

  Future<void> rejectUser(String userId, String phone) async {
    await _userDao.rejectAndBanUser(userId, phone);
    await loadDashboardData();
  }

  Future<void> deleteActiveAccount(String userId) async {
    await _userDao.deleteUser(
      userId,
    ); // SQLite CASCADE will wipe their cards/transactions
    await loadDashboardData();
  }
}
