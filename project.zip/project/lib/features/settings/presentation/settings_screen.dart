import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'settings_provider.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Listen to the settings state to update the UI instantly
    final settings = Provider.of<SettingsProvider>(context);

    return Scaffold(
      backgroundColor: settings.isDarkMode ? const Color(0xFF121212) : Colors.grey[50],
      appBar: AppBar(
        title: Text(
            "App Settings",
            style: TextStyle(
              fontWeight: FontWeight.bold,
              fontSize: 20 * settings.textScale,
              color: settings.isDarkMode ? Colors.white : const Color(0xFF0A2540),
            )
        ),
        backgroundColor: Colors.transparent,
        elevation: 0,
      ),
      body: ListView(
        padding: const EdgeInsets.all(24.0),
        children: [
          // APPEARANCE SECTION
          _buildSectionHeader("APPEARANCE", settings),
          Card(
            color: settings.isDarkMode ? Colors.grey[900] : Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: settings.isDarkMode ? Colors.grey[800]! : Colors.grey[200]!),
            ),
            child: Column(
              children: [
                SwitchListTile(
                  title: Text(
                      "Dark Mode",
                      style: TextStyle(fontWeight: FontWeight.w600, color: settings.isDarkMode ? Colors.white : Colors.black87, fontSize: 16 * settings.textScale)
                  ),
                  subtitle: Text(
                      "Switch to a darker visual theme",
                      style: TextStyle(color: Colors.grey, fontSize: 13 * settings.textScale)
                  ),
                  secondary: Icon(
                      settings.isDarkMode ? Icons.dark_mode : Icons.light_mode,
                      color: settings.isDarkMode ? Colors.amber : const Color(0xFF0A2540)
                  ),
                  value: settings.isDarkMode,
                  activeColor: Colors.amber,
                  onChanged: (value) => settings.toggleTheme(value),
                ),
                const Divider(height: 1),
                Padding(
                  padding: const EdgeInsets.symmetric(horizontal: 16.0, vertical: 12.0),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Icon(Icons.text_fields, color: settings.isDarkMode ? Colors.grey[400] : const Color(0xFF0A2540)),
                          const SizedBox(width: 16),
                          Text(
                              "UI Text Size",
                              style: TextStyle(fontWeight: FontWeight.w600, color: settings.isDarkMode ? Colors.white : Colors.black87, fontSize: 16 * settings.textScale)
                          ),
                        ],
                      ),
                      Slider(
                        value: settings.textScale,
                        min: 0.85, // Smallest allowed text
                        max: 1.3,  // Largest allowed text
                        divisions: 3,
                        activeColor: const Color(0xFF0A2540),
                        inactiveColor: Colors.grey[300],
                        label: _getScaleLabel(settings.textScale),
                        onChanged: (value) => settings.updateTextScale(value),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          const SizedBox(height: 32),

          // LOCALIZATION SECTION
          _buildSectionHeader("LOCALIZATION", settings),
          Card(
            color: settings.isDarkMode ? Colors.grey[900] : Colors.white,
            elevation: 0,
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(12),
              side: BorderSide(color: settings.isDarkMode ? Colors.grey[800]! : Colors.grey[200]!),
            ),
            child: ListTile(
              leading: Icon(Icons.language, color: settings.isDarkMode ? Colors.grey[400] : const Color(0xFF0A2540)),
              title: Text(
                  "App Language",
                  style: TextStyle(fontWeight: FontWeight.w600, color: settings.isDarkMode ? Colors.white : Colors.black87, fontSize: 16 * settings.textScale)
              ),
              subtitle: Text(
                  "Currently: ${settings.currentLanguage}",
                  style: TextStyle(color: Colors.grey, fontSize: 13 * settings.textScale)
              ),
              trailing: DropdownButton<String>(
                value: settings.currentLanguage,
                underline: const SizedBox(), // Removes the default line
                dropdownColor: settings.isDarkMode ? Colors.grey[850] : Colors.white,
                icon: const Icon(Icons.arrow_drop_down, color: Colors.grey),
                items: ['English', 'Turkish', 'Arabic'].map((String lang) {
                  return DropdownMenuItem<String>(
                    value: lang,
                    child: Text(
                        lang,
                        style: TextStyle(
                            color: settings.isDarkMode ? Colors.white : Colors.black87,
                            fontWeight: FontWeight.w500
                        )
                    ),
                  );
                }).toList(),
                onChanged: (String? newValue) {
                  if (newValue != null) settings.changeLanguage(newValue);
                },
              ),
            ),
          ),
        ],
      ),
    );
  }

  // Helper widget for clean section titles
  Widget _buildSectionHeader(String title, SettingsProvider settings) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8.0, left: 4.0),
      child: Text(
          title,
          style: TextStyle(
              fontSize: 12 * settings.textScale,
              fontWeight: FontWeight.bold,
              color: Colors.grey,
              letterSpacing: 1.2
          )
      ),
    );
  }

  // Helper logic to translate slider float values into readable text labels
  String _getScaleLabel(double scale) {
    if (scale < 1.0) return "Small";
    if (scale == 1.0) return "Default";
    if (scale < 1.2) return "Large";
    return "Extra Large";
  }
}