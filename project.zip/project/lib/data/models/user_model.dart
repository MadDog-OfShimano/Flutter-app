class UserModel {
  final String id;
  final String email;
  final String passwordHash;
  final bool mfaEnabled;
  final String? mfaSecret;
  final String accountStatus;
  final String fullName;
  final String phoneNumber;
  final String idDocumentPath;
  final String iban;
  final double balance;

  UserModel({
    required this.id,
    required this.email,
    required this.passwordHash,
    this.mfaEnabled = false,
    this.mfaSecret,
    this.accountStatus = 'PENDING_APPROVAL',
    required this.fullName,
    required this.phoneNumber,
    required this.idDocumentPath,
    required this.iban,
    this.balance = 0.00,
  });

  // Convert a Database Map row directly into a clear Dart Entity Object
  factory UserModel.fromMap(Map<String, dynamic> json) => UserModel(
    id: json['id'] as String,
    email: json['email'] as String,
    passwordHash: json['password_hash'] as String,
    mfaEnabled: json['mfa_enabled'] == 1,
    mfaSecret: json['mfa_secret'] as String?,
    accountStatus: json['account_status'] as String,
    fullName: json['full_name'] as String,
    phoneNumber: json['phone_number'] as String,
    idDocumentPath: json['id_document_path'] as String,
    iban: json['iban'] as String,
    balance: (json['balance'] as num).toDouble(),
  );

  // Convert a Dart Object into an optimized SQL insertion map
  Map<String, dynamic> toMap() => {
    'id': id,
    'email': email,
    'password_hash': passwordHash,
    'mfa_enabled': mfaEnabled ? 1 : 0,
    'mfa_secret': mfaSecret,
    'account_status': accountStatus,
    'full_name': fullName,
    'phone_number': phoneNumber,
    'id_document_path': idDocumentPath,
    'iban': iban,
    'balance': balance,
  };
}